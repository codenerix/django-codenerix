__version__ = "1.0.24"

__authors__ = [
    'Juan Miguel Taboada Godoy <juanmi@juanmitaboada.com>',
    'Juan Soler Ruiz <soleronline@gmail.com>',
    'Francisco Torrejon Puente <frantorrejon@gmail.com>',
]
